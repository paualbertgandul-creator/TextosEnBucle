package com.textos.bucle

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import java.io.File

data class Texto(val id: Long, val texto: String)

/**
 * Base de datos SQLite de la app: tabla "textos" (id, texto).
 */
class DbHelper(private val ctx: Context) : SQLiteOpenHelper(ctx, "textos.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS textos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "texto TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun todos(): List<Texto> {
        val lista = mutableListOf<Texto>()
        readableDatabase.rawQuery("SELECT id, texto FROM textos ORDER BY id", null).use { c ->
            while (c.moveToNext()) lista.add(Texto(c.getLong(0), c.getString(1) ?: ""))
        }
        return lista
    }

    fun anadir(texto: String) {
        writableDatabase.insert("textos", null, ContentValues().apply { put("texto", texto) })
    }

    fun actualizar(id: Long, texto: String) {
        writableDatabase.update(
            "textos", ContentValues().apply { put("texto", texto) },
            "id = ?", arrayOf(id.toString())
        )
    }

    fun borrar(id: Long) {
        writableDatabase.delete("textos", "id = ?", arrayOf(id.toString()))
    }

    /**
     * Importa textos desde otro archivo .db/.sqlite elegido por el usuario.
     * Si tiene una tabla "textos" con columna "texto", usa esa; si no, toma
     * la primera tabla que tenga una columna de texto. Los textos se AÑADEN
     * a los que ya hay. Devuelve cuántos se importaron.
     */
    fun importar(uri: Uri): Int {
        val tmp = File(ctx.cacheDir, "importar.db")
        ctx.contentResolver.openInputStream(uri)?.use { entrada ->
            tmp.outputStream().use { salida -> entrada.copyTo(salida) }
        } ?: throw IllegalArgumentException("No se pudo abrir el archivo")

        val textos = mutableListOf<String>()
        val origen = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val (tabla, columna) = buscarTablaYColumna(origen)
                ?: throw IllegalArgumentException("No encontré ninguna tabla con textos")
            origen.rawQuery("SELECT \"$columna\" FROM \"$tabla\"", null).use { c ->
                while (c.moveToNext()) {
                    val t = c.getString(0)
                    if (!t.isNullOrBlank()) textos.add(t)
                }
            }
        } finally {
            origen.close()
            tmp.delete()
        }

        val db = writableDatabase
        db.beginTransaction()
        try {
            textos.forEach { anadir(it) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return textos.size
    }

    private fun buscarTablaYColumna(db: SQLiteDatabase): Pair<String, String>? {
        val tablas = mutableListOf<String>()
        db.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' " +
                "AND name <> 'android_metadata'", null
        ).use { c -> while (c.moveToNext()) tablas.add(c.getString(0)) }

        // Preferencia: tabla "textos" con columna "texto"
        val orden = tablas.sortedBy { if (it.equals("textos", true)) 0 else 1 }
        for (tabla in orden) {
            var primeraTexto: String? = null
            db.rawQuery("PRAGMA table_info(\"$tabla\")", null).use { c ->
                while (c.moveToNext()) {
                    val nombre = c.getString(1)
                    val tipo = (c.getString(2) ?: "").uppercase()
                    if (nombre.equals("texto", true)) return tabla to nombre
                    if (primeraTexto == null &&
                        (tipo.contains("TEXT") || tipo.contains("CHAR") || tipo.contains("CLOB"))
                    ) primeraTexto = nombre
                }
            }
            primeraTexto?.let { return tabla to it }
        }
        return null
    }
}
