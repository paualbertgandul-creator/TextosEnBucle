# Textos en bucle (Android)

App que muestra en pantalla, uno tras otro y en bucle, los textos guardados en una base de datos SQLite.

## Qué hace
- **Pantalla principal**: enseña cada texto en grande y pasa al siguiente cada N segundos (de 1 a 60, con la barra). Botones ◀ / Pausa / ▶, y tocar el texto avanza. La pantalla no se apaga mientras está abierta.
- **Añadir / editar textos**: lista de todos los textos. Toca uno para modificarlo o borrarlo; «+ Añadir» crea uno nuevo.
- **Importar .db**: elige un archivo `.db` / `.sqlite` del móvil y añade sus textos. Usa la tabla `textos` (columna `texto`) si existe; si no, la primera tabla con una columna de texto.

Los textos se guardan en la base SQLite interna de la app (`textos.db`, tabla `textos(id, texto)`).

## Cómo instalarla
1. Instala **Android Studio** (gratis) en tu ordenador.
2. *File → Open* y elige la carpeta `TextosEnBucle`. Espera a que termine la sincronización de Gradle (descarga lo necesario la primera vez).
3. En el móvil activa *Opciones de desarrollador → Depuración USB* y conéctalo por cable.
4. Pulsa ▶ *Run*. La app se instala y se abre.

Para obtener un APK y pasarlo al móvil sin cable: *Build → Build App Bundle(s) / APK(s) → Build APK(s)*; el archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android 7.0 o superior.
