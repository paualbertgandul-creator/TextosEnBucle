package com.textos.bucle

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Pantalla principal: muestra los textos uno tras otro, en bucle.
 */
class MainActivity : Activity() {

    private lateinit var db: DbHelper
    private lateinit var tvTexto: TextView
    private lateinit var tvContador: TextView
    private lateinit var tvVelocidad: TextView
    private lateinit var btnPausa: Button

    private val handler = Handler(Looper.getMainLooper())
    private var textos: List<Texto> = emptyList()
    private var indice = 0
    private var segundos = 5
    private var enPausa = false

    private val siguiente = object : Runnable {
        override fun run() {
            if (textos.isNotEmpty()) {
                indice = (indice + 1) % textos.size
                mostrar()
            }
            handler.postDelayed(this, segundos * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val prefs = getPreferences(MODE_PRIVATE)
        segundos = prefs.getInt("segundos", 5)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        tvContador = TextView(this).apply { gravity = Gravity.CENTER; textSize = 14f }

        tvTexto = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad, 0, pad)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(tvTexto, MATCH_PARENT, WRAP_CONTENT)
            // Tocar el texto pasa al siguiente
            tvTexto.setOnClickListener { avanzarManual(1) }
        }

        tvVelocidad = TextView(this)
        val seek = SeekBar(this).apply {
            max = 59 // 1 a 60 segundos
            progress = segundos - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    segundos = p + 1
                    actualizarVelocidad()
                    prefs.edit().putInt("segundos", segundos).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { reiniciarTemporizador() }
            })
        }

        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnAnterior = Button(this).apply { text = "◀"; setOnClickListener { avanzarManual(-1) } }
        btnPausa = Button(this).apply { setOnClickListener { alternarPausa() } }
        val btnSiguiente = Button(this).apply { text = "▶"; setOnClickListener { avanzarManual(1) } }
        val peso = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        fila.addView(btnAnterior, peso)
        fila.addView(btnPausa, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.5f))
        fila.addView(btnSiguiente, peso)

        val btnTextos = Button(this).apply {
            text = "Añadir / editar textos"
            setOnClickListener { startActivity(Intent(this@MainActivity, TextosActivity::class.java)) }
        }

        raiz.addView(tvContador, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        raiz.addView(tvVelocidad, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(seek, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(fila, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(btnTextos, MATCH_PARENT, WRAP_CONTENT)
        setContentView(raiz)

        actualizarVelocidad()
        actualizarBotonPausa()
    }

    override fun onResume() {
        super.onResume()
        textos = db.todos()
        if (indice >= textos.size) indice = 0
        mostrar()
        if (!enPausa) reiniciarTemporizador()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(siguiente)
    }

    private fun mostrar() {
        if (textos.isEmpty()) {
            tvTexto.text = "No hay textos todavía.\nPulsa «Añadir / editar textos»."
            tvContador.text = ""
        } else {
            tvTexto.text = textos[indice].texto
            tvContador.text = "${indice + 1} / ${textos.size}"
        }
    }

    private fun avanzarManual(paso: Int) {
        if (textos.isEmpty()) return
        indice = (indice + paso + textos.size) % textos.size
        mostrar()
        if (!enPausa) reiniciarTemporizador()
    }

    private fun reiniciarTemporizador() {
        handler.removeCallbacks(siguiente)
        if (!enPausa) handler.postDelayed(siguiente, segundos * 1000L)
    }

    private fun alternarPausa() {
        enPausa = !enPausa
        actualizarBotonPausa()
        if (enPausa) handler.removeCallbacks(siguiente) else reiniciarTemporizador()
    }

    private fun actualizarBotonPausa() {
        btnPausa.text = if (enPausa) "Reanudar" else "Pausa"
    }

    private fun actualizarVelocidad() {
        tvVelocidad.text = "Cambiar cada $segundos s"
    }
}
