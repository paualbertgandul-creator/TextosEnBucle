plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.textos.bucle"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.textos.bucle"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // Clave fija: permite instalar nuevas versiones encima sin perder los textos.
    signingConfigs {
        create("fija") {
            storeFile = file("firma.jks")
            storePassword = "textosbucle"
            keyAlias = "textos"
            keyPassword = "textosbucle"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fija")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fija")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias externas: solo el SDK de Android.
