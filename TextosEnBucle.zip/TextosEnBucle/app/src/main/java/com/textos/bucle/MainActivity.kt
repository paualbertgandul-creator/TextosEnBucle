package com.textos.bucle

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/**
 * Pantalla principal: imprime los textos en bucle.
 *  - Espera 0 s: los textos se imprimen uno tras otro sin parar, como en una terminal.
 *  - Espera > 0 s: se muestra un texto cada vez y cambia tras la espera.
 */
class MainActivity : Activity() {

    private lateinit var db: DbHelper
    private lateinit var tvTexto: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tvContador: TextView
    private lateinit var tvVelocidad: TextView
    private lateinit var btnPausa: Button

    private val handler = Handler(Looper.getMainLooper())
    private var textos: List<Texto> = emptyList()
    private var indice = 0
    private var segundos = 0
    private var enPausa = false

    /** Líneas impresas en modo continuo (se guardan solo las últimas). */
    private val impresos = ArrayDeque<String>()
    private val maxImpresos = 300

    private val siguiente = object : Runnable {
        override fun run() {
            if (textos.isNotEmpty()) {
                indice = (indice + 1) % textos.size
                mostrar()
            }
            // Sin espera: siguiente texto en el próximo fotograma de pantalla.
            handler.postDelayed(this, if (segundos == 0) 16L else segundos * 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DbHelper(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val prefs = getPreferences(MODE_PRIVATE)
        segundos = prefs.getInt("espera", 0)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        tvContador = TextView(this).apply { gravity = Gravity.CENTER; textSize = 14f }

        tvTexto = TextView(this).apply {
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad, 0, pad)
            setOnClickListener { avanzarManual(1) }
        }
        scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(tvTexto, MATCH_PARENT, WRAP_CONTENT)
        }

        tvVelocidad = TextView(this)
        val seek = SeekBar(this).apply {
            max = 60 // 0 (sin espera) a 60 segundos
            progress = segundos
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val antes = segundos
                    segundos = p
                    if ((antes == 0) != (segundos == 0)) cambiarModo()
                    actualizarVelocidad()
                    prefs.edit().putInt("espera", segundos).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { reiniciarTemporizador() }
            })
        }

        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnAnterior = Button(this).apply { text = "◀"; setOnClickListener { avanzarManual(-1) } }
        btnPausa = Button(this).apply { setOnClickListener { alternarPausa() } }
        val btnSiguiente = Button(this).apply { text = "▶"; setOnClickListener { avanzarManual(1) } }
        fila.addView(btnAnterior, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        fila.addView(btnPausa, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1.5f))
        fila.addView(btnSiguiente, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))

        val btnTextos = Button(this).apply {
            text = "Añadir / editar textos"
            setOnClickListener { startActivity(Intent(this@MainActivity, TextosActivity::class.java)) }
        }

        raiz.addView(tvContador, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(scroll, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        raiz.addView(tvVelocidad, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(seek, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(fila, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(btnTextos, MATCH_PARENT, WRAP_CONTENT)
        setContentView(raiz)

        cambiarModo()
        actualizarVelocidad()
        actualizarBotonPausa()
    }

    override fun onResume() {
        super.onResume()
        textos = db.todos()
        if (indice >= textos.size) indice = 0
        mostrar()
        if (!enPausa) reiniciarTemporizador()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(siguiente)
    }

    /** Ajusta el aspecto según el modo: continuo (0 s) o un texto cada vez. */
    private fun cambiarModo() {
        impresos.clear()
        if (segundos == 0) {
            tvTexto.gravity = Gravity.START
            tvTexto.textSize = 18f
        } else {
            tvTexto.gravity = Gravity.CENTER
            tvTexto.textSize = 28f
        }
        if (::tvContador.isInitialized && textos.isNotEmpty()) mostrar()
    }

    private fun mostrar() {
        if (textos.isEmpty()) {
            tvTexto.text = "No hay textos todavía.\nPulsa «Añadir / editar textos»."
            tvContador.text = ""
            return
        }
        tvContador.text = "${indice + 1} / ${textos.size}"
        if (segundos == 0) {
            impresos.addLast(textos[indice].texto)
            while (impresos.size > maxImpresos) impresos.removeFirst()
            tvTexto.text = impresos.joinToString("\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        } else {
            tvTexto.text = textos[indice].texto
            scroll.scrollTo(0, 0)
        }
    }

    private fun avanzarManual(paso: Int) {
        if (textos.isEmpty()) return
        indice = (indice + paso + textos.size) % textos.size
        mostrar()
        if (!enPausa) reiniciarTemporizador()
    }

    private fun reiniciarTemporizador() {
        handler.removeCallbacks(siguiente)
        if (!enPausa) handler.postDelayed(siguiente, if (segundos == 0) 16L else segundos * 1000L)
    }

    private fun alternarPausa() {
        enPausa = !enPausa
        actualizarBotonPausa()
        if (enPausa) handler.removeCallbacks(siguiente) else reiniciarTemporizador()
    }

    private fun actualizarBotonPausa() {
        btnPausa.text = if (enPausa) "Reanudar" else "Pausa"
    }

    private fun actualizarVelocidad() {
        tvVelocidad.text = if (segundos == 0) "Sin espera (impresión continua)" else "Cambiar cada $segundos s"
    }
}
