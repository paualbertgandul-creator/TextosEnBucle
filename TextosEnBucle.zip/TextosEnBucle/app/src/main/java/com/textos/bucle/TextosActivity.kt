package com.textos.bucle

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast

/**
 * Lista de textos: tocar uno para editarlo o borrarlo, botón para añadir
 * y botón para importar desde otro archivo SQLite.
 */
class TextosActivity : Activity() {

    private lateinit var db: DbHelper
    private lateinit var adapter: ArrayAdapter<String>
    private var textos: List<Texto> = emptyList()

    companion object { private const val PEDIR_ARCHIVO = 1 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.setDisplayHomeAsUpEnabled(true)
        db = DbHelper(this)

        val pad = (12 * resources.displayMetrics.density).toInt()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val fila = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnAnadir = Button(this).apply { text = "+ Añadir"; setOnClickListener { editar(null) } }
        val btnImportar = Button(this).apply { text = "Importar .db"; setOnClickListener { elegirArchivo() } }
        val peso = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        fila.addView(btnAnadir, peso)
        fila.addView(btnImportar, peso)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        val lista = ListView(this).apply {
            adapter = this@TextosActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> editar(textos[pos]) }
        }

        raiz.addView(fila, MATCH_PARENT, WRAP_CONTENT)
        raiz.addView(lista, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        setContentView(raiz)
        recargar()
    }

    override fun onNavigateUp(): Boolean { finish(); return true }

    private fun recargar() {
        textos = db.todos()
        adapter.clear()
        adapter.addAll(textos.map { it.texto })
        title = "Mis textos (${textos.size})"
    }

    /** Diálogo para crear (texto == null) o modificar un texto. */
    private fun editar(texto: Texto?) {
        val campo = EditText(this).apply {
            setText(texto?.texto ?: "")
            minLines = 3
            hint = "Escribe el texto"
        }
        val b = AlertDialog.Builder(this)
            .setTitle(if (texto == null) "Nuevo texto" else "Editar texto")
            .setView(campo)
            .setPositiveButton("Guardar") { _, _ ->
                val valor = campo.text.toString().trim()
                if (valor.isEmpty()) return@setPositiveButton
                if (texto == null) db.anadir(valor) else db.actualizar(texto.id, valor)
                recargar()
            }
            .setNegativeButton("Cancelar", null)
        if (texto != null) {
            b.setNeutralButton("Borrar") { _, _ ->
                AlertDialog.Builder(this)
                    .setMessage("¿Borrar este texto?")
                    .setPositiveButton("Borrar") { _, _ -> db.borrar(texto.id); recargar() }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
        b.show()
    }

    private fun elegirArchivo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, PEDIR_ARCHIVO)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PEDIR_ARCHIVO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val n = db.importar(uri)
            Toast.makeText(this, "Importados $n textos", Toast.LENGTH_LONG).show()
            recargar()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al importar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
